<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->
- [x] Verify that the copilot-instructions.md file in the .github directory is created.

- [x] Clarify Project Requirements
	Mobile app similar to UWorld for medical exam preparation with practice questions, explanations, progress tracking, and study modes. Using React Native for cross-platform development.

- [x] Scaffold the Project
	Created React Native project structure with package.json, App.tsx, sample screens (HomeScreen, QuizScreen), components (QuestionCard), and sample medical question data. Project is ready for dependency installation.

- [x] Customize the Project
	Added offline functionality with AsyncStorage, DataService for local storage, DataManagementScreen for MCQ import/export, and comprehensive MCQ template. App now supports full offline operation with user's own questions.

- [x] Install Required Extensions
	No specific extensions required for React Native development.

- [x] Compile the Project
	Project is ready for compilation. All necessary dependencies listed in package.json. Users need to run 'npm install' after extraction to install dependencies locally.

- [x] Create and Run Task
	No specific tasks required. Standard React Native commands (npm start, npm run android/ios) are sufficient.

- [x] Launch the Project
	Project ready for launch. Users can run 'npm start' then 'npm run android' or 'npm run ios' after installing dependencies and setting up development environment.

- [x] Ensure Documentation is Complete
	README.md and SETUP_GUIDE.md provide comprehensive instructions. copilot-instructions.md file exists and contains current project information.
